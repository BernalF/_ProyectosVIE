USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_USUARIOS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_USUARIOS_GET]
GO

USE [Proyectos_VIE]
GO
/****** Object:  StoredProcedure [dbo].[SP_FP_AD_USUARIOS_GET]    Script Date: 03/05/2014 01:30:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero L.
-- Create date: 12/11/2013
-- Description:	Retorna una lista de USUARIOS
-- =============================================
CREATE PROCEDURE [dbo].[SP_FP_AD_USUARIOS_GET] 
	@pUserId INT = NULL
AS
BEGIN
	
	SET NOCOUNT ON;

	SELECT	 a.UserId
			,a.UserName
			,a.LDAP_USERNAME as LdapUserName
			,b.RoleId
			,c.RoleName
    FROM dbo.UserProfile a
    INNER JOIN dbo.webpages_UsersInRoles b ON a.UserId = b.UserId
    INNER JOIN dbo.webpages_Roles c ON b.RoleId = c.RoleId
    WHERE @pUserId IS NULL OR a.UserId = @pUserId
    
    SET NOCOUNT OFF;
END
