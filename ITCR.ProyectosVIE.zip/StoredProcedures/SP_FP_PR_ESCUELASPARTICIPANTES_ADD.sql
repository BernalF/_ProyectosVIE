USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_ESCUELASPARTICIPANTES_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_ESCUELASPARTICIPANTES_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez ROjas
-- Create date: 17/12/2013
-- Description:	Inserta  Escuelas o Instituciones participantes
-- =============================================
CREATE PROCEDURE SP_FP_PR_ESCUELASPARTICIPANTES_ADD 
(				   
   @pID_INSTITUCION INT
   ,@pTIPOINSTITUCION VARCHAR(2)
   ,@pID_PROYECTO INT
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
				 DECLARE @CANTIDAD INT
				 DECLARE @ID_TIPOINSTITUCION INT
            
            SELECT @ID_TIPOINSTITUCION = ID_TIPOINSTITUCION FROM dbo.FP_AD_TIPOINSTITUCIONES WHERE @pTIPOINSTITUCION = COD_TIPOINSTITUCION
				
            SELECT @CANTIDAD = COUNT(*) FROM [FP_PR_ESCUELASPARTICIPANTES] WHERE @pID_INSTITUCION = ID_INSTITUCION AND @ID_TIPOINSTITUCION = ID_TIPOINSTITUCION AND @pID_PROYECTO = ID_PROYECTO
                        
            IF @CANTIDAD = 0
			BEGIN				
				
				INSERT INTO [FP_PR_ESCUELASPARTICIPANTES]
					   (ID_INSTITUCION
					  ,ID_TIPOINSTITUCION
					  ,ID_PROYECTO)
				 VALUES
					   (@pID_INSTITUCION
						,@ID_TIPOINSTITUCION
						,@pID_PROYECTO)	
						
				SELECT SCOPE_IDENTITY()		
           END 
           ELSE
			SELECT -1
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() > 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











