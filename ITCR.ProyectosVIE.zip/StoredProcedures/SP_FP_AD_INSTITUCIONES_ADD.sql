USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_INSTITUCIONES_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_INSTITUCIONES_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez Rojas
-- Create date: 31/08/2013
-- Description:	Inserta o Actualiza info de Instituiciones
-- =============================================
CREATE PROCEDURE SP_FP_AD_INSTITUCIONES_ADD 
(
	@pID_INSTITUCION INT = NULL,
	@pCOD_INSTITUCION VARCHAR(10),
	@pDSC_NOMBRE VARCHAR(100) = NULL,
	@pID_TIPOINSTITUCION VARCHAR(1) = NULL
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
            DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM FP_AD_INSTITUCIONES WHERE ID_INSTITUCION = @pID_INSTITUCION
                        
            IF @CANTIDAD = 0
			BEGIN
				INSERT INTO [FP_AD_INSTITUCIONES]
					   (COD_INSTITUCION
						,DSC_NOMBRE
						,ID_TIPOINSTITUCION)
				 VALUES
					   (@pCOD_INSTITUCION
						,@pDSC_NOMBRE
						,@pID_TIPOINSTITUCION)
			END
			ELSE
			BEGIN
				UPDATE [FP_AD_INSTITUCIONES]
				SET COD_INSTITUCION = @pCOD_INSTITUCION
					,DSC_NOMBRE = @pDSC_NOMBRE
					,ID_TIPOINSTITUCION = @pID_TIPOINSTITUCION
				WHERE ID_INSTITUCION = @pID_INSTITUCION
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











