USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_FI_INVESTIGADOR_GET]    Script Date: 11/09/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_FI_INVESTIGADOR_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_FI_INVESTIGADOR_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 05/11/2013
-- Description:	Retorna Informacion General Ficha Investigador
-- =============================================
CREATE PROCEDURE SP_FP_FI_INVESTIGADOR_GET 
	@pID_INVESTIGADOR INT 	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
	   [ID_INVESTIGADOR]
      ,[IDENTIFICACION]
      ,[LDAP_USERNAME]
      ,[NOMBRE]
      ,[APELLIDO1]
      ,[APELLIDO2]
      ,[CELULAR]
      ,[TELEFONO]
      ,[EMAIL]
      ,[APTOPOSTAL]
      ,[PSEUDONIMO]
      ,[COD_PAIS_NACIONALIDAD]
      ,[FEC_NACIMIENTO]
      ,[COD_PAIS_NACIO]
      ,[GENERO]
      ,[ID_INSTITUCION]
      ,[FEC_INGRESO]
      ,[IND_SITUACION_LABORAL]
      ,[CATACADEMICA]
      ,[IMG_FOTO]  
      ,[GOOGLE_SCHOLAR]   
    FROM dbo.FP_FI_INVESTIGADOR
    WHERE ID_INVESTIGADOR = @pID_INVESTIGADOR
    
    SET NOCOUNT OFF;
END
GO
