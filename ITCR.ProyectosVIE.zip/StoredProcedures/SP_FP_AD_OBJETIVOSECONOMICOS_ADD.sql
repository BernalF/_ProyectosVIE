USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_OBJETIVOSECONOMICOS_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_OBJETIVOSECONOMICOS_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora Flores
-- Create date: 31/08/2013
-- Description:	Inserta o Actualiza info de disciplinas
-- =============================================
CREATE PROCEDURE SP_FP_AD_OBJETIVOSECONOMICOS_ADD 
(
			@pID_OBJETIVOSECONOMICOS INT = NULL,
			@pCOD_OBJETIVO VARCHAR(2),
			@pDSC_OBJETIVO VARCHAR(40),
			@pIND_ACTIVO VARCHAR(1) = NULL
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
            DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM FP_AD_OBJETIVOSECONOMICOS WHERE ID_OBJETIVOSECONOMICOS = @pID_OBJETIVOSECONOMICOS
                        
            IF @CANTIDAD = 0
			BEGIN
				INSERT INTO [FP_AD_OBJETIVOSECONOMICOS]
					   (COD_OBJETIVO
						,DSC_OBJETIVO
						,IND_ACTIVO)
				 VALUES
					   (@pCOD_OBJETIVO
						,@pDSC_OBJETIVO
						,@pIND_ACTIVO)
			END
			ELSE
			BEGIN
				UPDATE [FP_AD_OBJETIVOSECONOMICOS]
				SET COD_OBJETIVO = @pCOD_OBJETIVO
					,DSC_OBJETIVO = @pDSC_OBJETIVO
					,IND_ACTIVO = @pIND_ACTIVO
				WHERE ID_OBJETIVOSECONOMICOS = @pID_OBJETIVOSECONOMICOS
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











