USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PLAN_DIFUSION_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PLAN_DIFUSION_ADD]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 29/01/2014
-- Description:	Inserta PLAN_DIFUSION
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PLAN_DIFUSION_ADD] 
(				   
		   @pMEDIO_DESCRIPCION VARCHAR(max) = NULL		 
		  ,@pXML_MEDIOS VARCHAR(max) = NULL	
		  ,@pID_PROYECTO INT
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0            
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END                         

			DECLARE @CANTIDAD INT
			DECLARE @xmlHandler INT
			DECLARE @SCOPE_IDENTITY INT
						  
            SELECT @CANTIDAD = COUNT(*) FROM [FP_PR_PLAN_DIFUSION] WHERE ID_PROYECTO = @pID_PROYECTO
                        
            IF @CANTIDAD = 0
            BEGIN			          					
				INSERT INTO [dbo].[FP_PR_PLAN_DIFUSION]
					   ([MEDIO_DESCRIPCION]
					  ,[ID_PROYECTO])
				 VALUES
					   (@pMEDIO_DESCRIPCION
					  ,@pID_PROYECTO)   
					
				SELECT @SCOPE_IDENTITY = SCOPE_IDENTITY()	  
				
				SET @pXML_MEDIOS = REPLACE(@pXML_MEDIOS,'{ID_PLAN_DIFUSION}', @SCOPE_IDENTITY)	  
				
				EXEC sp_xml_preparedocument @xmlHandler OUTPUT, @pXML_MEDIOS 	
				
				DELETE FROM FP_PR_PLAN_DIFUSION_MEDIOS
				WHERE ID_PLAN_DIFUSION 
					IN (
						SELECT	ID_PLAN_DIFUSION
							FROM OPENXML (@xmlHandler, '/ROOT/Medios', 1)
									WITH(	ID_PLAN_DIFUSION INT 'ID_PLAN_DIFUSION',
											ID_PROYECTO INT 'ID_PROYECTO') 
						WHERE 	ID_PROYECTO = @pID_PROYECTO	)

				INSERT INTO FP_PR_PLAN_DIFUSION_MEDIOS
				SELECT	ID_PLAN_DIFUSION,
						ID_MEDIO
					FROM OPENXML (@xmlHandler, '/ROOT/Medios', 1)
							WITH(	ID_MEDIO INT 'ID_MEDIO', 
									ID_PLAN_DIFUSION INT 'ID_PLAN_DIFUSION',
									CHECKED VARCHAR(100) 'CHECKED') 
				WHERE 	CHECKED = 1
				                       
            END
            ELSE
            BEGIN	
				EXEC sp_xml_preparedocument @xmlHandler OUTPUT, @pXML_MEDIOS 
                      									
				DELETE FROM FP_PR_PLAN_DIFUSION_MEDIOS
				WHERE ID_PLAN_DIFUSION 
					IN (
						SELECT	ID_PLAN_DIFUSION
							FROM OPENXML (@xmlHandler, '/ROOT/Medios', 1)
									WITH(	ID_PLAN_DIFUSION INT 'ID_PLAN_DIFUSION',
											ID_PROYECTO INT 'ID_PROYECTO') 
						WHERE 	ID_PROYECTO = @pID_PROYECTO	)

				INSERT INTO FP_PR_PLAN_DIFUSION_MEDIOS
				SELECT	ID_PLAN_DIFUSION,
						ID_MEDIO
					FROM OPENXML (@xmlHandler, '/ROOT/Medios', 1)
							WITH(	ID_MEDIO INT 'ID_MEDIO', 
									ID_PLAN_DIFUSION INT 'ID_PLAN_DIFUSION',
									CHECKED VARCHAR(100) 'CHECKED') 
				WHERE 	CHECKED = 1		
				
				UPDATE [FP_PR_PLAN_DIFUSION]
				SET  [MEDIO_DESCRIPCION] = @pMEDIO_DESCRIPCION 
					,[ID_PROYECTO] = COALESCE(@pID_PROYECTO, [ID_PROYECTO]) 
				WHERE ID_PROYECTO = @pID_PROYECTO											
            END			
						
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
					EXEC sp_xml_removedocument @xmlHandler  
                    COMMIT TRANSACTION
                END
	                
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
					EXEC sp_xml_removedocument @xmlHandler  
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO