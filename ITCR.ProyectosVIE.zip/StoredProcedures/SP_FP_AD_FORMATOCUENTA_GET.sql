USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_FORMATOCUENTA_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_FORMATOCUENTA_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_FORMATOCUENTA_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de formato de cuenta contable
-- =============================================
CREATE PROCEDURE SP_FP_AD_FORMATOCUENTA_GET 
	@pID_FORMATO varchar(3) = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 ID_FORMATO
        ,DSC_FORMATO
        ,FEC_INICIO
        ,FEC_FINAL        
    FROM FP_AD_FORMATOCUENTA
    WHERE @pID_FORMATO IS NULL OR ID_FORMATO = @pID_FORMATO
    
    SET NOCOUNT OFF;
END
GO
