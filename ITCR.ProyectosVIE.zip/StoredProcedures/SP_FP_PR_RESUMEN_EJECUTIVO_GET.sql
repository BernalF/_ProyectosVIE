USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PROYECTO_RESUMEN_EJECUTIVO_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_RESUMEN_EJECUTIVO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_RESUMEN_EJECUTIVO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandex
-- Create date: 1/29/2014
-- Description:	Retorna RESUMEN_EJECUTIVO
-- =============================================
CREATE PROCEDURE [SP_FP_PR_RESUMEN_EJECUTIVO_GET] 
	@pID_PROYECTO INT = NULL	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT 
	   [ID_RESUMEN_EJECUTIVO]
      ,[RESUMEN_EJECUTIVO]
      ,[ID_PROYECTO]  
    FROM [FP_PR_RESUMEN_EJECUTIVO] 
    WHERE ID_PROYECTO = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
GO
