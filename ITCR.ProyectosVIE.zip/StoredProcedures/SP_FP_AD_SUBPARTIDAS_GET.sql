USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_SUBPARTIDAS_GET]    Script Date: 2014 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_SUBPARTIDAS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_SUBPARTIDAS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 22/Mayo/2014
-- Description:	Retorna una lista de supartidas
-- =============================================
CREATE PROCEDURE SP_FP_AD_SUBPARTIDAS_GET 
	@pID_CUENTA INT = null,
	@pID_PROYECTO INT
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		  a.ID_CUENTA		  
		  ,CASE WHEN a.POSICION > 1 THEN  '###'
				ELSE ''
			END + NUM_CUENTA + ' ' + DESCRIPCION AS RUBRO_CONTABLE       
    FROM dbo.FP_AD_CUENTASCONTABLES a
    INNER JOIN dbo.FP_PR_PRESUPUESTO b
		ON a.ID_CUENTA = b.ID_CUENTA
    WHERE (@pID_CUENTA IS NULL OR a.ID_CUENTA = @pID_CUENTA) 
      AND b.HIDDEN = 0
      AND b.ID_PROYECTO = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
GO
