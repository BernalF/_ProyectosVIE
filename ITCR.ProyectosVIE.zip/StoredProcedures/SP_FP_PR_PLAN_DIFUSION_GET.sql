USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PLAN_DIFUSION_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PLAN_DIFUSION_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PLAN_DIFUSION_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 28/01/2014
-- Description:	Retorna una lista de PLAN_DIFUSION
-- =============================================
CREATE PROCEDURE SP_FP_PR_PLAN_DIFUSION_GET 
	@pID_PROYECTO INT = null	
AS
BEGIN	
	SET NOCOUNT ON;

	DECLARE @tmp TABLE(
		ID_PLAN_DIFUSION [int]  NULL,
		MEDIO_DESCRIPCION [varchar](max)  NULL,
		[ID_PROYECTO] [int]  NULL
	)

	INSERT INTO @tmp
	SELECT	e.ID_PLAN_DIFUSION
		   ,e.MEDIO_DESCRIPCION
		   ,e.[ID_PROYECTO]
	FROM dbo.FP_PR_PLAN_DIFUSION e
    WHERE @pID_PROYECTO = [ID_PROYECTO] 
    
    IF(SELECT COUNT(1) 
		FROM @tmp ) = 0 
		BEGIN
			INSERT INTO @tmp VALUES (NULL, NULL, @pID_PROYECTO)
		END    

	SELECT	e.ID_PLAN_DIFUSION
		   ,e.MEDIO_DESCRIPCION
		   ,e.[ID_PROYECTO]
		   ,(SELECT * FROM 
				(SELECT  a.ID_MEDIO, 
						a.DSC_MEDIO, 
						c.ID_PLAN_DIFUSION, 
						1 as CHECKED
				FROM dbo.FP_AD_MEDIOS a 
				INNER JOIN dbo.FP_PR_PLAN_DIFUSION_MEDIOS b 
					ON a.ID_MEDIO = b.ID_MEDIO
				INNER JOIN dbo.FP_PR_PLAN_DIFUSION c 
					ON b.ID_PLAN_DIFUSION = c.ID_PLAN_DIFUSION
				WHERE c.ID_PROYECTO = @pID_PROYECTO
			UNION   
				SELECT  a.ID_MEDIO, 
						a.DSC_MEDIO, 
						NULL AS ID_PLAN_DIFUSION, 
						0 as CHECKED
				FROM dbo.FP_AD_MEDIOS a   
				WHERE NOT EXISTS ( SELECT  x.ID_MEDIO 
								   FROM dbo.FP_PR_PLAN_DIFUSION_MEDIOS x
								   INNER JOIN dbo.FP_PR_PLAN_DIFUSION y
									 ON x.ID_PLAN_DIFUSION = y.ID_PLAN_DIFUSION
								   WHERE y.ID_PROYECTO = @pID_PROYECTO 
									 AND a.ID_MEDIO = x.ID_MEDIO  ) ) T
				ORDER BY DSC_MEDIO
				FOR XML RAW('Medios'), ROOT ('ROOT'), ELEMENTS )  XML_MEDIOS   
    FROM @tmp e
    
    SET NOCOUNT OFF;
END