USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_LINEA_INVESTIGACION_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_LINEA_INVESTIGACION_ADD]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 29/01/2014
-- Description:	Inserta LINEA_INVESTIGACION
-- =============================================
CREATE PROCEDURE [SP_FP_PR_LINEA_INVESTIGACION_ADD] 
(		
		   @pID_LINEA_INVESTIGACION INT = NULL
		  ,@pLINEA_INVESTIGACION VARCHAR(max) = NULL		 
		  ,@pID_PROYECTO INT
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0            
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END                         

			DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM [FP_PR_LINEA_INVESTIGACION] WHERE ID_PROYECTO = @pID_PROYECTO
                        
            IF @CANTIDAD = 0
            BEGIN
				INSERT INTO [dbo].[FP_PR_LINEA_INVESTIGACION]
					   ([LINEA_INVESTIGACION]
					  ,[ID_PROYECTO])
				 VALUES
					   (@pLINEA_INVESTIGACION
					  ,@pID_PROYECTO)
            END
            ELSE
            BEGIN
				UPDATE [FP_PR_LINEA_INVESTIGACION]
				SET  [LINEA_INVESTIGACION] = COALESCE(@pLINEA_INVESTIGACION, [LINEA_INVESTIGACION]) 
					,[ID_PROYECTO] = COALESCE(@pID_PROYECTO, [ID_PROYECTO]) 
				WHERE ID_PROYECTO = @pID_PROYECTO
            END			
			
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO