USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_JUSTIFICACIONPRESUP_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_JUSTIFICACIONPRESUP_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero L.
-- Create date: 28/01/2014
-- Description:	Inserta  info de JUSTIFICACIONPRESUP
-- =============================================
CREATE PROCEDURE SP_FP_PR_JUSTIFICACIONPRESUP_ADD 
(				   
	   @pID_PROYECTO INT
	  ,@pID_CUENTA INT
	  ,@pDESCRIPCION VARCHAR(MAX)
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
				INSERT INTO [FP_PR_JUSTIFICACIONPRESUP]
					   ( ID_PROYECTO
						,ID_CUENTA
						,DESCRIPCION)
				 VALUES
					   ( @pID_PROYECTO
						,@pID_CUENTA
						,@pDESCRIPCION)						
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() > 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO