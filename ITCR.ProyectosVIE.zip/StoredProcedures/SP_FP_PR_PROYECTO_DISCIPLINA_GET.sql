USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PROYECTO_DISCIPLINA_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PROYECTO_DISCIPLINA_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PROYECTO_DISCIPLINA_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandex
-- Create date: 31/08/2013
-- Description:	Retorna DISCIPLINA
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PROYECTO_DISCIPLINA_GET] 
	@pID_PROYECTO INT = NULL	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT 
	   x.[ID_PDISCIPLINA]
	  ,x.[ID_DISCIPLINA]     
      ,x.[ID_CARRERA]      
      ,x.[ID_PROYECTO]  
    FROM [FP_PR_DISCIPLINA] x  
    WHERE ID_PROYECTO = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
GO
