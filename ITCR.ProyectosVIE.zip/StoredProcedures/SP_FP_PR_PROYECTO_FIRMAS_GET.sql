USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PROYECTO_FIRMAS_GET]    Script Date: 01/02/2014 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PROYECTO_FIRMAS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PROYECTO_FIRMAS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 01/02/2014
-- Description:	Retorna FIRMAS
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PROYECTO_FIRMAS_GET] 
	@pID_PROYECTO INT = NULL	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT 
	     [ID_FIRMAS]
		,[COORDINADOR_NOMBRE]
		,[COORDINADOR_CED]
		,[COORDINADOR_FIRMA]
		,[DIRECTOR_NOMBRE]
		,[DIRECTOR_CED]
		,[DIRECTOR_FIRMA]
		,[ID_PROYECTO]
    FROM [FP_PR_FIRMAS]
    WHERE [ID_PROYECTO] = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
GO
