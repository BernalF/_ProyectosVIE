USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_DISTRITOS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_DISTRITOS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_DISTRITOS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de cantones
-- =============================================
CREATE PROCEDURE SP_FP_AD_DISTRITOS_GET 
	@pID_DISTRITO INT = NULL
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		x.ID_DISTRITO
		,x.COD_DISTRITO
		,x.DSC_DISTRITO
        ,x.ID_CANTON
        ,y.DSC_CANTON        
        ,x.ID_PROVINCIA  
        ,z.DSC_PROVINCIA   
    FROM FP_AD_DISTRITOS x
    INNER JOIN FP_AD_CANTONES y ON x.ID_CANTON = y.ID_CANTON
    INNER JOIN FP_AD_PROVINCIAS z ON x.ID_PROVINCIA = z.ID_PROVINCIA
    WHERE @pID_DISTRITO IS NULL OR ID_DISTRITO = @pID_DISTRITO
			
    SET NOCOUNT OFF;
END
GO
