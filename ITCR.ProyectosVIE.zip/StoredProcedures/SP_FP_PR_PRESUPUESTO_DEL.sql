USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PRESUPUESTO_DEL]    Script Date: 03/MAYO/2014 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PRESUPUESTO_DEL]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PRESUPUESTO_DEL]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 03/MAYO/2014
-- Description:	Elimina/Oculta Linea de PRESUPUESTO
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PRESUPUESTO_DEL] 
	@pID_PROYECTO INT,
	@pID_PRESUPUESTO INT
AS
BEGIN
	
	SET NOCOUNT ON;
	
	UPDATE [dbo].[FP_PR_PRESUPUESTO] 
	SET HIDDEN = 1
	WHERE   ID_PROYECTO = @pID_PROYECTO
		AND ID_PRESUPUESTO = @pID_PRESUPUESTO
    
    SET NOCOUNT OFF;
END
GO
