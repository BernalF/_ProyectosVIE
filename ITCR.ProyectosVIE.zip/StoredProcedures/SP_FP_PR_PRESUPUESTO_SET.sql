USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PRESUPUESTO_SET]    Script Date: 03/MAYO/2014 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PRESUPUESTO_SET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PRESUPUESTO_SET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 03/MAYO/2014
-- Description:	Actualiza Linea de PRESUPUESTO
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PRESUPUESTO_SET] 
	@pID_PROYECTO INT,
	@pID_PRESUPUESTO INT,
	@pMONTO1 MONEY,
	@pMONTO2 MONEY,
	@pMONTO3 MONEY
	
AS
BEGIN
	
	SET NOCOUNT ON;
	
	UPDATE [dbo].[FP_PR_PRESUPUESTO] 
	SET MONTO1 = @pMONTO1
	   ,MONTO2 = @pMONTO2
	   ,MONTO3 = @pMONTO3
	   ,TOTAL = @pMONTO1 + @pMONTO2 + @pMONTO3
	WHERE   ID_PROYECTO = @pID_PROYECTO
		AND ID_PRESUPUESTO = @pID_PRESUPUESTO
    
    SET NOCOUNT OFF;
END
GO
