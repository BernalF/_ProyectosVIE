USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PLANADMINRIESGO_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PLANADMINRIESGO_ADD]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 25/Mayo/2014
-- Description:	Inserta PLANADMINRIESGO
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PLANADMINRIESGO_ADD] 
(		
		   @pID_PLANADMINRIESGO INT
		  ,@pRIESGOS VARCHAR(MAX) = NULL
		  ,@pACCIONES VARCHAR(MAX) = NULL
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0            
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END                         

				UPDATE dbo.FP_PR_PLANADMINRIESGO
				SET  RIESGOS = @pRIESGOS
					,ACCIONES = @pACCIONES
				WHERE ID_PLANADMINRIESGO = @pID_PLANADMINRIESGO
          
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO