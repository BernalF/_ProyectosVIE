USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_FI_INVESTIGADOR_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_FI_INVESTIGADOR_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez Rojas
-- Create date: 11/09/2013
-- Description:	Inserta o Actualiza info general Ficha Universitaria
-- =============================================
CREATE PROCEDURE SP_FP_FI_INVESTIGADOR_ADD 
(
			 @pID_INVESTIGADOR INT = NULL
			,@pIDENTIFICACION VARCHAR(30)
			,@pLDAP_USERNAME VARCHAR(50)  = NULL
			,@pNOMBRE VARCHAR(30)
			,@pAPELLIDO1 VARCHAR(30)
			,@pAPELLIDO2 VARCHAR(30) = NULL
			,@pTELEFONO VARCHAR(12) = NULL
			,@pCELULAR VARCHAR(12) = NULL
			,@pEMAIL VARCHAR(50) = NULL
			,@pAPTOPOSTAL VARCHAR(50) = NULL
			,@pPSEUDONIMO VARCHAR(50) = NULL
			,@pCOD_PAIS_NACIONALIDAD INT = NULL
			,@pFEC_NACIMIENTO date = NULL
			,@pCOD_PAIS_NACIO INT = NULL
			,@pGENERO CHAR(1) = NULL
			,@pID_INSTITUCION INT = NULL
			,@pFEC_INGRESO date = NULL
			,@pIND_SITUACION_LABORAL CHAR(1) = NULL
			,@pCATACADEMICA VARCHAR(30) = NULL
			,@pIMG_FOTO VARCHAR(MAX) = NULL
			,@pGOOGLE_SCHOLAR VARCHAR(MAX) = NULL
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
            DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM dbo.FP_FI_INVESTIGADOR WHERE ID_INVESTIGADOR = @pID_INVESTIGADOR
                        
            IF @CANTIDAD = 0
			BEGIN
				INSERT INTO [FP_FI_INVESTIGADOR]
					   (IDENTIFICACION
					   ,LDAP_USERNAME
					   ,NOMBRE
					   ,APELLIDO1
					   ,APELLIDO2
					   ,CELULAR
					   ,TELEFONO
					   ,EMAIL
					   ,APTOPOSTAL
					   ,PSEUDONIMO
					   ,COD_PAIS_NACIONALIDAD
					   ,FEC_NACIMIENTO
					   ,COD_PAIS_NACIO
					   ,GENERO
					   ,ID_INSTITUCION
					   ,FEC_INGRESO
					   ,IND_SITUACION_LABORAL
					   ,CATACADEMICA
					   ,IMG_FOTO
					   ,GOOGLE_SCHOLAR)
				 VALUES
					   (@pIDENTIFICACION 
						,@pLDAP_USERNAME 
						,@pNOMBRE
						,@pAPELLIDO1
						,@pAPELLIDO2 
						,@pTELEFONO
						,@pCELULAR 
						,@pEMAIL
						,@pAPTOPOSTAL 
						,@pPSEUDONIMO 
						,@pCOD_PAIS_NACIONALIDAD
						,@pFEC_NACIMIENTO
						,@pCOD_PAIS_NACIO
						,@pGENERO
						,@pID_INSTITUCION 
						,@pFEC_INGRESO 
						,@pIND_SITUACION_LABORAL 
						,@pCATACADEMICA
						,@pIMG_FOTO
						,@pGOOGLE_SCHOLAR)
						
					SELECT SCOPE_IDENTITY()					
			END
			ELSE
			BEGIN
				UPDATE [FP_FI_INVESTIGADOR]
				SET [IDENTIFICACION] = COALESCE(@pIDENTIFICACION, [IDENTIFICACION]) 
				  ,[LDAP_USERNAME] = COALESCE(@pLDAP_USERNAME, [LDAP_USERNAME]) 
				  ,[NOMBRE] = COALESCE(@pNOMBRE, [NOMBRE]) 
				  ,[APELLIDO1] = COALESCE(@pAPELLIDO1, [APELLIDO1]) 
				  ,[APELLIDO2] = COALESCE(@pAPELLIDO2, [APELLIDO2]) 
				  ,[CELULAR] = COALESCE(@pCELULAR, [CELULAR]) 
				  ,[TELEFONO] = COALESCE(@pTELEFONO, [TELEFONO]) 
				  ,[EMAIL] = COALESCE(@pEMAIL, [EMAIL]) 
				  ,[APTOPOSTAL] = COALESCE(@pAPTOPOSTAL, [APTOPOSTAL]) 
				  ,[PSEUDONIMO] = COALESCE(@pPSEUDONIMO, [PSEUDONIMO]) 
				  ,[COD_PAIS_NACIONALIDAD] = COALESCE(@pCOD_PAIS_NACIONALIDAD, [COD_PAIS_NACIONALIDAD]) 
				  ,[FEC_NACIMIENTO] = COALESCE(@pFEC_NACIMIENTO, [FEC_NACIMIENTO]) 
				  ,[COD_PAIS_NACIO] = COALESCE(@pCOD_PAIS_NACIO, [COD_PAIS_NACIO]) 
				  ,[GENERO] = COALESCE(@pGENERO,[GENERO]) 
				  ,[ID_INSTITUCION] = COALESCE(@pID_INSTITUCION, [ID_INSTITUCION]) 
				  ,[FEC_INGRESO] = COALESCE(@pFEC_INGRESO, [FEC_INGRESO]) 
				  ,[IND_SITUACION_LABORAL] = COALESCE(@pIND_SITUACION_LABORAL, [IND_SITUACION_LABORAL]) 
				  ,[CATACADEMICA] = COALESCE(@pCATACADEMICA, [CATACADEMICA]) 
				  ,[IMG_FOTO] = COALESCE(@pIMG_FOTO, [IMG_FOTO])
				  ,[GOOGLE_SCHOLAR] = COALESCE(@pGOOGLE_SCHOLAR, [GOOGLE_SCHOLAR])
				WHERE ID_INVESTIGADOR = @pID_INVESTIGADOR
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











