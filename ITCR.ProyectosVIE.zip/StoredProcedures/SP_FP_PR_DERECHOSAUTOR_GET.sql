USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PROYECTO_DERECHOSAUTOR_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_DERECHOSAUTOR_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_DERECHOSAUTOR_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandex
-- Create date: 1/29/2014
-- Description:	Retorna DERECHOSAUTOR
-- =============================================
CREATE PROCEDURE [SP_FP_PR_DERECHOSAUTOR_GET] 
	@pID_PROYECTO INT = NULL	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT 
	   [ID_DERECHOSAUTOR]
      ,[CONVENIO_NACIONAL]
      ,[CONVENIO_INTERNACIONAL]
      ,[PI_ITCR]
      ,[PI_FUNDATEC]
      ,[PI_CONTRA]
      ,[PI_CONTRA_VALOR]
      ,[CONVENIO_MARCO]
      ,[P2_PR_GEN_PROTECCION]
      ,[P3_PR_CORR_INVESTIGACION]
      ,[P4_RELACION]
      ,[ID_PROYECTO]  
    FROM [FP_PR_DERECHOSAUTOR] 
    WHERE ID_PROYECTO = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
GO
