USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_CARRERAS_BY_DISCIPLINA_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_CARRERAS_BY_DISCIPLINA_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_CARRERAS_BY_DISCIPLINA_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de Carreras by disciplinas
-- =============================================
CREATE PROCEDURE SP_FP_AD_CARRERAS_BY_DISCIPLINA_GET 
	@pID_DISCIPLINA INT	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 c.ID_CARRERA
		 ,c.ID_DISCIPLINA
        ,c.DSC_CARRERA       
    FROM FP_AD_CARRERAS c
    LEFT JOIN FP_AD_DISCIPLINAS d ON c.ID_DISCIPLINA = d.ID_DISCIPLINA
    WHERE c.ID_DISCIPLINA = @pID_DISCIPLINA
    
    SET NOCOUNT OFF;
END
GO
