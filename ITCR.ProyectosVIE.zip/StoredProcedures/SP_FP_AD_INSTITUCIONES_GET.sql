USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_INSTITUCIONES_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_INSTITUCIONES_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_INSTITUCIONES_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez Rojas
-- Create date: 16/11/2013
-- Description:	Retorna una lista de tipos de Instituciones
-- =============================================
CREATE PROCEDURE SP_FP_AD_INSTITUCIONES_GET
	@pID_INSTITUCION INT = NULL
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 a.ID_INSTITUCION
		,a.COD_INSTITUCION
        ,a.DSC_NOMBRE        
        ,a.ID_TIPOINSTITUCION
        ,b.DSC_TIPOINSTITUCION
    FROM FP_AD_INSTITUCIONES a
    INNER JOIN dbo.FP_AD_TIPOINSTITUCIONES b ON a.ID_TIPOINSTITUCION = b.ID_TIPOINSTITUCION
    WHERE @pID_INSTITUCION IS NULL OR ID_INSTITUCION = @pID_INSTITUCION
    
    SET NOCOUNT OFF;
END
GO
