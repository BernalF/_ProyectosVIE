USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_DISCIPLINAS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_DISCIPLINAS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_DISCIPLINAS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de disciplinas
-- =============================================
CREATE PROCEDURE SP_FP_AD_DISCIPLINAS_GET 
	@pID_DISCIPLINA INT = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 d.ID_DISCIPLINA
		 ,d.COD_DISCIPLINA
        ,d.DSC_DISCIPLINA 
    FROM FP_AD_DISCIPLINAS d
    WHERE @pID_DISCIPLINA IS NULL OR ID_DISCIPLINA = @pID_DISCIPLINA
    
    SET NOCOUNT OFF;
END
GO
