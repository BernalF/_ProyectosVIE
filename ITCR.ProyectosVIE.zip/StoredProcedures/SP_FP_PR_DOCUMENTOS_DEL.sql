USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_DOCUMENTOS_DEL]    Script Date: 03/MAYO/2014 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_DOCUMENTOS_DEL]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_DOCUMENTOS_DEL]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 03/MAYO/2014
-- Description:	Insert or Update DOCUMENTOS
-- =============================================
CREATE PROCEDURE [SP_FP_PR_DOCUMENTOS_DEL] 
	@pID_DOCUMENTO INT
AS
BEGIN
	
	SET NOCOUNT ON;
	
	UPDATE [dbo].[FP_PR_DOCUMENTOS]
    SET ID_ARCHIVO = ''
	   ,NOMBRE_ARCHIVO = ''
    WHERE ID_DOCUMENTO = @pID_DOCUMENTO
    
    SET NOCOUNT OFF;
END
GO
