USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_FINANEXTERNO_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_FINANEXTERNO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_FINANEXTERNO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero L.
-- Create date: 28/01/2014
-- Description:	Retorna una lista de FINANEXTERNO
-- =============================================
CREATE PROCEDURE SP_FP_PR_FINANEXTERNO_GET 
	@pID_PROYECTO INT 	
AS
BEGIN
	
	SET NOCOUNT ON;

	SELECT	 ID_FINANEXTERNO
		    ,ID_PROYECTO
			,MONTO
			,ESTADOTRAMITE
			,NOMBRE
			,FUENTE 
    FROM dbo.FP_PR_FINANEXTERNO
	WHERE [ID_PROYECTO] = @pID_PROYECTO
	
    SET NOCOUNT OFF;
END
