USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_PROVINCIAS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_PROVINCIAS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_PROVINCIAS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de provincias
-- =============================================
CREATE PROCEDURE SP_FP_AD_PROVINCIAS_GET 
	@pID_PROVINCIA INT = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 x.ID_PROVINCIA
		 ,x.COD_PROVINCIA
         ,x.DSC_PROVINCIA
         ,x.ID_PAIS      
         ,y.DSC_PAIS 
    FROM FP_AD_PROVINCIAS x
    INNER JOIN FP_AD_PAIS y ON x.ID_PAIS = y.ID_PAIS
    WHERE @pID_PROVINCIA IS NULL OR ID_PROVINCIA = @pID_PROVINCIA
    
    SET NOCOUNT OFF;
END
GO
