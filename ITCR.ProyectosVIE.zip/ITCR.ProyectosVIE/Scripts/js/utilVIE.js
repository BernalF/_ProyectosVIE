﻿var ProyectosVIE = ProyectosVIE || {};

ProyectosVIE.utilVIE = (function () {
    var options = {};

    //initialize function
    var initialize = function () { };

    //forms Initializer function
    var formsInitializer = function () {
        boostRequiredMVC();
    };
    //Adaptaction for MVC required fields with boostrap messages errors
    var boostRequiredMVC = function () {
        jQuery.extend(jQuery.validator.methods, {
            required: function (value, element) {
                element = $(element);
                if (element.attr('data-val-required')) {
                    if (value.length == 0) {
                        element.closest('.control-group').addClass('error');
                        element.closest('.span12').siblings('.error').children('span').show();

                        return false;
                    } else {
                        element.closest('.control-group').removeClass('error');
                        element.closest('.span12').siblings('.error').children('span').hide();
                        return true;
                    }
                }
            }
        });
    };
    //Clear fields in ajax begin form
    var ajaxClearFields = function () {
        $('form.form-inline').find('input:text, input[type=number], textarea').val('');
    };
    //delete Form
    var delForm = function () {
        $('#grid').off('click.t', 'button[gE]').on('click.t', 'button[gE]', function (e) {
            var $form = $('#FIdeleteForm');
            $form.find('#id').val($(this).attr('id'));
            $('#FIaDelete').trigger('click');
            e.stopPropagation();
        });
    };

    //Public methods
    return {
        init: initialize,
        formsInit: formsInitializer,
        clearFields: ajaxClearFields,
        deleteForm: delForm
    };
})();

