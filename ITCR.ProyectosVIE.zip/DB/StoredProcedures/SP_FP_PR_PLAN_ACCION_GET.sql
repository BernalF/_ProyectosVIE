USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PLAN_ACCION_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PLAN_ACCION_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PLAN_ACCION_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 28/01/2014
-- Description:	Retorna una lista de PLAN_ACCION
-- =============================================
CREATE PROCEDURE SP_FP_PR_PLAN_ACCION_GET 
	@pID_PROYECTO INT = null	
AS
BEGIN
	
	SET NOCOUNT ON;

	SELECT	e.ID_PLAN_ACCION
		   ,e.OBJETIVO_GENERAL	   
		   ,e.[ID_PROYECTO]  
    FROM dbo.FP_PR_PLAN_ACCION e
    WHERE [ID_PROYECTO] = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
