USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PROYECTO_DATOSGENERALES_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PROYECTO_DATOSGENERALES_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 31/08/2013
-- Description:	Inserta Datos Generales
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PROYECTO_DATOSGENERALES_ADD] 
(
			@pID_PROYECTO INT = NULL,
			@pNOM_PROYECTO VARCHAR(max),
			@pOBJETIVO VARCHAR(max),
			@pPALABRASCLAVE VARCHAR(200) = NULL,
			@pOBJETIVO_INGLES VARCHAR(max) = NULL,
			@pKEYWORDS VARCHAR (200) = NULL			
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0            
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END                         

			DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM [FP_PR_PROYECTO] WHERE ID_PROYECTO = @pID_PROYECTO
                        
            IF @CANTIDAD = 0
            BEGIN
				INSERT INTO [dbo].[FP_PR_PROYECTO]
					   ([NOM_PROYECTO]
					   ,[OBJETIVO]
					   ,[PALABRASCLAVE]
					   ,[OBJETIVO_INGLES]
					   ,[KEYWORDS])
				 VALUES
					   (@pNOM_PROYECTO
					   ,@pOBJETIVO
					   ,@pPALABRASCLAVE
					   ,@pOBJETIVO_INGLES
					   ,@pKEYWORDS)
            END
            ELSE
            BEGIN
				UPDATE [FP_PR_PROYECTO]
				SET NOM_PROYECTO = COALESCE(@pNOM_PROYECTO, [NOM_PROYECTO]) 
					,OBJETIVO = COALESCE(@pOBJETIVO, [OBJETIVO]) 
					,[PALABRASCLAVE] = COALESCE(@pPALABRASCLAVE, [PALABRASCLAVE]) 
					,[OBJETIVO_INGLES] = COALESCE(@pOBJETIVO_INGLES, [OBJETIVO_INGLES]) 
					,[KEYWORDS] = COALESCE(@pKEYWORDS, [KEYWORDS]) 
				WHERE ID_PROYECTO = @pID_PROYECTO
            END			
			
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO