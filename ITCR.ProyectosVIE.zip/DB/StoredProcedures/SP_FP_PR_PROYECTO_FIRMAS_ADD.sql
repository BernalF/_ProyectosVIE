USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PROYECTO_FIRMAS_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PROYECTO_FIRMAS_ADD]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 01/02/2014
-- Description:	Inserta Firmas
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PROYECTO_FIRMAS_ADD] 
(
	 @pID_FIRMAS [int] = NULL
	,@pCOORDINADOR_NOMBRE [varchar](100)
	,@pCOORDINADOR_CED [varchar](100)
	,@pCOORDINADOR_FIRMA [varchar](max) = NULL
	,@pDIRECTOR_NOMBRE [varchar](100) = NULL
	,@pDIRECTOR_CED [varchar](100) = NULL
	,@pDIRECTOR_FIRMA [varchar](max) = NULL
	,@pID_PROYECTO [int]				
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0            
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END                         

			DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM [FP_PR_FIRMAS] WHERE ID_FIRMAS = @pID_FIRMAS
                        
            IF @CANTIDAD = 0
            BEGIN
				INSERT INTO [dbo].[FP_PR_FIRMAS]
					(COORDINADOR_NOMBRE
					,COORDINADOR_CED
					,COORDINADOR_FIRMA
					,DIRECTOR_NOMBRE
					,DIRECTOR_CED
					,DIRECTOR_FIRMA
					,ID_PROYECTO)
				 VALUES
					(@pCOORDINADOR_NOMBRE
					,@pCOORDINADOR_CED
					,@pCOORDINADOR_FIRMA
					,@pDIRECTOR_NOMBRE
					,@pDIRECTOR_CED
					,@pDIRECTOR_FIRMA
					,@pID_PROYECTO)
            END
            ELSE
            BEGIN
				UPDATE [FP_PR_FIRMAS]
				SET  COORDINADOR_NOMBRE = COALESCE(@pCOORDINADOR_NOMBRE, COORDINADOR_NOMBRE) 
					,COORDINADOR_CED = COALESCE(@pCOORDINADOR_CED, COORDINADOR_CED) 
					,COORDINADOR_FIRMA = COALESCE(@pCOORDINADOR_FIRMA, COORDINADOR_FIRMA)
					,DIRECTOR_NOMBRE = COALESCE(@pDIRECTOR_NOMBRE, DIRECTOR_NOMBRE) 
					,DIRECTOR_CED = COALESCE(@pDIRECTOR_CED, DIRECTOR_CED)
					,DIRECTOR_FIRMA = COALESCE(@pDIRECTOR_FIRMA, DIRECTOR_FIRMA) 
					,ID_PROYECTO = COALESCE(@pID_PROYECTO, ID_PROYECTO)					
				WHERE ID_FIRMAS = @pID_FIRMAS
            END			
			
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()
                    
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO