USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_FI_ARTICULOS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_FI_ARTICULOS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_FI_ARTICULOS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 12/11/2013
-- Description:	Retorna una lista de ARTICULOS
-- =============================================
CREATE PROCEDURE SP_FP_FI_ARTICULOS_GET 
	@pID_INVESTIGADOR INT 	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		   [ID_ARTICULOS]		  
		  ,[TITULO]
		  ,[REVISTA]
		  ,[INDEXADAEN]
		  ,[NUM_VOLUMEN]
		  ,[NUM_NUMERO]
		  ,[ANNO]
		  ,[ID_INVESTIGADOR]    
    FROM dbo.FP_FI_ARTICULOS
    WHERE ID_INVESTIGADOR = @pID_INVESTIGADOR
    
    SET NOCOUNT OFF;
END
GO
