USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_INSTITUCIONESByTIPO_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_INSTITUCIONESByTIPO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_INSTITUCIONESByTIPO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez Rojas
-- Create date: 16/11/2013
-- Description:	Retorna una lista de tipos de INSTITUCIONES  por TIPO
-- =============================================
CREATE PROCEDURE SP_FP_AD_INSTITUCIONESByTIPO_GET
	@pTIPO VARCHAR(2)
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE @ltipo INT
	SELECT @ltipo = ID_TIPOINSTITUCION FROM dbo.FP_AD_TIPOINSTITUCIONES WHERE COD_TIPOINSTITUCION = @pTIPO
	
    SELECT
		 ID_INSTITUCION
		,COD_INSTITUCION
        ,DSC_NOMBRE
    FROM dbo.FP_AD_INSTITUCIONES
    WHERE ID_TIPOINSTITUCION = @ltipo
    ORDER BY DSC_NOMBRE ASC

    
    SET NOCOUNT OFF;
END
GO
