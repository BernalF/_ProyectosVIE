USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_TIPOSPROYECTO_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_TIPOSPROYECTO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_TIPOSPROYECTO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de tipos de PROYECTOs
-- =============================================
CREATE PROCEDURE SP_FP_AD_TIPOSPROYECTO_GET 
	@pID_TIPOPROYECTO INT = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 ID_TIPOPROYECTO
		 ,COD_TIPOPROYECTO
        ,DSC_TIPOPROYECTO        
    FROM FP_AD_TIPOSPROYECTO
    WHERE @pID_TIPOPROYECTO IS NULL OR ID_TIPOPROYECTO = @pID_TIPOPROYECTO
    
    SET NOCOUNT OFF;
END
GO
