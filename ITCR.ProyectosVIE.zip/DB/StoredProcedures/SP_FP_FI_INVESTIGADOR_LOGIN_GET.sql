USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_FI_INVESTIGADOR_GET]    Script Date: 11/09/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_FI_INVESTIGADOR_LOGIN_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_FI_INVESTIGADOR_LOGIN_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero.
-- Create date: 09/11/2013
-- Description:	Retorna Informacion para login
-- =============================================
CREATE PROCEDURE SP_FP_FI_INVESTIGADOR_LOGIN_GET 
	@pLDAP_USERNAME VARCHAR(50)
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
	   [ID_INVESTIGADOR]
      ,[LDAP_USERNAME]
    FROM dbo.FP_FI_INVESTIGADOR
    WHERE LDAP_USERNAME = @pLDAP_USERNAME
    
    SET NOCOUNT OFF;
END
GO
