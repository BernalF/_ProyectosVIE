USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_FI_TESIS_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_FI_TESIS_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez ROjas
-- Create date: 05/11/2013
-- Description:	Inserta  info de TESIS
-- =============================================
CREATE PROCEDURE SP_FP_FI_TESIS_ADD 
(				   
   @pTEMA varchar(100) = NULL
   ,@pID_ESCUELA int   = NULL
   ,@pGRADO char(3)
   ,@pANNO varchar(4) = NULL
   ,@pID_INVESTIGADOR int  
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
				INSERT INTO [FP_FI_TESIS]
					   ([TEMA]
					  ,[ID_ESCUELA]
					  ,[GRADO]
					  ,[ANNO]
					  ,[ID_INVESTIGADOR])
				 VALUES
					   (@pTEMA
						,@pID_ESCUELA
						,@pGRADO
						,@pANNO
						,@pID_INVESTIGADOR)		
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() > 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











