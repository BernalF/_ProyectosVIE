USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_FI_LIBROS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_FI_LIBROS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_FI_LIBROS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero L.
-- Create date: 12/11/2013
-- Description:	Retorna una lista de LIBROS
-- =============================================
CREATE PROCEDURE SP_FP_FI_LIBROS_GET 
	@pID_INVESTIGADOR INT 	
AS
BEGIN
	
	SET NOCOUNT ON;

	SELECT	ID_LIBROS,
			NOMBRE,
			EDITORIAL,
			ANNO,
			ID_INVESTIGADOR  
    FROM dbo.FP_FI_LIBROS
    WHERE ID_INVESTIGADOR = @pID_INVESTIGADOR
    
    SET NOCOUNT OFF;
END
GO
