﻿var ProyectosVIE = ProyectosVIE || {};

ProyectosVIE.planAccion = (function () {
	var options = {};

	//initialize function
	var initialize = function (opts) {
		$.extend(options, opts);
		addProductos();
		addActividades();
		addResponsables();
		deleteHandler();
		modalActitiesHide();
	};

	var addProductos = function () {
		$('#grid').off('click.t', 'button[gp]').on('click.t', 'button[gp]', function (e) {
			var $form = $('#FIaddPlanAccionProductos');
			$form.find('#id').val($(this).attr('id'));
			$('#productos').val($(this).siblings('span').text());
			$('#FIaAddPlanAccionProductos').trigger('click');
			e.stopPropagation();
		});
	};

	var addActividades = function () {
		$('#grid').off('click.t', 'button[ga]').on('click.t', 'button[ga]', function (e) {
			var $form = $('#FIaddPlanAccionActividades');

			loadActividades($(this).siblings('span').text());

			$form.find('#id').val($(this).attr('id'));

			$('#FIaAddPlanAccionActividades').trigger('click');
			e.stopPropagation();
		});
	};

	var fillList = function (data) {
		ProyectosVIE.utilVIE.clearFields();

		var text = data.ACTIVIDAD;
		var actID = data.ID_PLAN_ACCION_OBJETIVOS_ACTIVIDADES;

		var cnt = [];
		cnt.push('<tr id="' + actID + '"><td>');
		cnt.push(text);
		cnt.push('</td><td><button class="btn btn-danger btn-small btn-block"><i class="icon-remove"></i></button></td></tr>');
		$('#Tactividades').append(cnt.join(''));
	};

	var addResponsables = function () {
		$('#grid').off('click.t', 'button[gr]').on('click.t', 'button[gr]', function (e) {
			var $form = $('#FIaddPlanAccionResponsables');
			$form.find('#id').val($(this).attr('id'));
			$('#responsables').val($(this).siblings('span').text());
			$('#FIaAddPlanAccionResponsables').trigger('click');
			e.stopPropagation();
		});
	};

	var deleteHandler = function () {
		$('#Tactividades').off('click.tEscuelas', 'button').on('click.tEscuelas', 'button', function () {
			var $tr = $(this).closest('tr');

			$.ajax({
				url: options.url.del,
				type: 'POST',
				data: JSON.stringify({ id: $tr.attr('id') }),
				contentType: 'application/json; charset=utf-8',
				error: function () {
					alert("error");
				}
			});
			$tr.fadeOut().remove();
		});
	};

	var loadActividades = function (txtData) {
		var data = $.parseJSON(txtData);
		$('#Tactividades').html('');

		for (i = 0; i < data.length; ++i) {
			fillList(data[i]);
		}
	};

	var modalActitiesHide = function() {
		$('#FIaddPlanAccionActividades').on('hidden', function () {
			window.location = options.url.index;
		});
	};

	//Public methods
	return {
		init: initialize,
		ajaxFill: fillList
	};
})();

