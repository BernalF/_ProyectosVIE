﻿var ProyectosVIE = ProyectosVIE || {};

ProyectosVIE.cronograma = (function () {
	var options = {};

	//initialize function		
	var initialize = function (opts) {
		$.extend(options, opts);
		periodCheck();
		loadPeriods();
	};

	var periodCheck = function () {
		$('.period')
			.off('click.period', 'th')
			.on('click.period', 'th', function (e) {
				var $span = $(this).find('span');
				var ele = $span.siblings('input:radio');

				$span.toggleClass("selected");

				if (ele.is(':checked')) {
					ele.prop('checked', false);
				} else {
					ele.prop('checked', true);
				}
			});
	};

	var loadPeriods = function () {
		$('.period').find('input:radio:checked').each(function () {
			$(this).siblings('span').addClass('selected');
		});
	};

	//Public methods
	return {
		init: initialize
	};
})();

