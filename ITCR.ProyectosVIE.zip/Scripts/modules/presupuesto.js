﻿(function ($) {
    $.fn.money_field = function (options) {
        var defaults = {
            width: null
        };
        var options = $.extend(defaults, options);

        return this.each(function () {
            obj = $(this);
            if (options.width)
                obj.css('width', options.width + 'px');
            obj.wrap("<div class='input-prepend'>");
            obj.before("<span class='add-on'>&#8353;</span>");
        });
    };
})(jQuery);

var ProyectosVIE = ProyectosVIE || {};

ProyectosVIE.presupuesto = (function () {
    var options = {};

    //initialize function
    var initialize = function () {
        addMoneyStyle();
        addOnBlurFunc();
    };

    var addMoneyStyle = function () {
        $('.money').money_field({ width: 80 });
    }
    var addOnBlurFunc = function () {
        var list = $("#content_presupuesto");
        list.off("blur.list change.list", "input[name='MONTO1']").on("blur.list change.list", "input[name='MONTO1']", function () {
            var self = $(this);
            var objTotal = self.closest("tr").find("input[name='TOTAL']");
            var objMonto2 = self.closest("tr").find("input[name='MONTO2']");
            var objMonto3 = self.closest("tr").find("input[name='MONTO3']");
            self.val(formatCurrency(toNum(self.val())));
            objTotal.val(formatCurrency(toNum(objMonto2.val()) + toNum(objMonto3.val()) + toNum(self.val())));
            updateTotal();
        });

        list.off("blur.list change.list", "input[name='MONTO2']").on("blur.list change.list", "input[name='MONTO2']", function () {
            var self = $(this);
            var objTotal = self.closest("tr").find("input[name='TOTAL']");
            var objMonto1 = self.closest("tr").find("input[name='MONTO1']");
            var objMonto3 = self.closest("tr").find("input[name='MONTO3']");
            self.val(formatCurrency(toNum(self.val())));
            objTotal.val(formatCurrency(toNum(objMonto1.val()) + toNum(objMonto3.val())  + toNum(self.val())));
            updateTotal();
        });

        list.off("blur.list change.list", "input[name='MONTO3']").on("blur.list change.list", "input[name='MONTO3']", function () {
            var self = $(this);
            var objTotal = self.closest("tr").find("input[name='TOTAL']");
            var objMonto1 = self.closest("tr").find("input[name='MONTO1']");
            var objMonto2 = self.closest("tr").find("input[name='MONTO2']");
            self.val(formatCurrency(toNum(self.val())));
            objTotal.val(formatCurrency(toNum(objMonto1.val()) + toNum(objMonto2.val()) + toNum(self.val())));
            updateTotal();
        });
    };

    var updateTotal = function() {
        var self = $("#TOTAL_FINAL");
        var total = 0.00;
        $("input[name='TOTAL']").each(function() {
            total += toNum(this.value);
        });
        self.val(formatCurrency(total));
    }



    var toNum= function (num) {
        return isNaN(num) || num === '' || num === null ? 0.00 : parseFloat(num);
    }
    var formatCurrency = function (num) {
        return toNum(num).toFixed(0);
    }

    //Public methods
    return {
        init: initialize
    };
})();


(function ($) {
    $.fn.money_field = function (options) {
        var defaults = {
            width: null
        };
        var options = $.extend(defaults, options);

        return this.each(function () {
            obj = $(this);
            if (options.width)
                obj.css('width', options.width + 'px');
            obj.wrap("<div class='input-prepend'>");
            obj.before("<span class='add-on'>&#8353;</span>");
        });
    };
})(jQuery);
