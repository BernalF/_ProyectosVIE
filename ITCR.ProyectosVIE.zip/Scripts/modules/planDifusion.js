﻿var ProyectosVIE = ProyectosVIE || {};

ProyectosVIE.planDifusion = (function () {
	var options = {};
	var $xml = $($('#XML_MEDIOS').val()).find('Medios');

	//initialize function	
	var initialize = function (opts) {
		$.extend(options, opts);
		loadMedios();
		savePlanDifusion();
	};

	var loadMedios = function () {
		var content = [];

		$xml.each(function (i, ele) {
			var $ele = $(ele);
			content.push('<li class="checkbox pull-left">');
			content.push('<input type="checkbox" value="' + $ele.find('ID_MEDIO').text() + '" ');		
			content.push($ele.find('CHECKED').text() == 0 ? '/>' : 'checked />');
			content.push('<label>' + $ele.find('DSC_MEDIO').text() + '</label>');
			content.push('</li>');
		});
		$('#mediosArea').html(content.join(''));
	};

	var savePlanDifusion = function () {
		$('#btnSavePD')
			.off('click.btnSavePD')
			.on('click.btnSavePD', function () {
				var xml = [];
				xml.push('<?xml version="1.0" encoding="ISO-8859-1" ?><ROOT>');
				$('#mediosArea').find('input:checkbox').each(function (i, ele) {
					var $ele = $(ele);
					xml.push('<Medios><ID_MEDIO>');
					xml.push($ele.val());
					xml.push('</ID_MEDIO>');
					xml.push('<DSC_MEDIO>');
					xml.push($ele.siblings('label').text());
					xml.push('</DSC_MEDIO>');
					xml.push('<ID_PLAN_DIFUSION>');
					xml.push($ele.is(':checked') && $('#ID_PLAN_DIFUSION').val() == '' ? '{ID_PLAN_DIFUSION}' : $('#ID_PLAN_DIFUSION').val());
					xml.push('</ID_PLAN_DIFUSION>');
					xml.push('<CHECKED>');
					xml.push($ele.is(':checked') ? 1 : 0);
					xml.push('</CHECKED>');
					xml.push('<ID_PROYECTO>');
					xml.push($('#ID_PROYECTO').val());
					xml.push('</ID_PROYECTO></Medios>');
				});
				xml.push('</ROOT>');
				$('#XML_MEDIOS').val(xml.join(''));
			console.log(xml.join(''));
			$(this).closest('form').submit();
		});
	};

	//Public methods
	return {
		init: initialize
	};
})();

