﻿
var ProyectosVIE = ProyectosVIE || {};

ProyectosVIE.proyecto = (function () {
    var options = {};

    //initialize function
    var initialize = function () {       
        setDatePicker();
    };
    ///set Date Picker
    var setDatePicker = function () {

        $('#DatosGenerales_FECHA_INICIO_STR').datepicker({
            format: 'dd/mm/yyyy'
        });
        $('#DatosGenerales_FECHA_FINAL_STR').datepicker({
            format: 'dd/mm/yyyy'
        });
    };
    
    //Public methods
    return {
        init: initialize
    };

})();