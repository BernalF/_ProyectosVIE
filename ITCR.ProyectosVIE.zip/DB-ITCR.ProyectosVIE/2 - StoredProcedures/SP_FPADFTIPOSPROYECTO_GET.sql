USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FPADFTIPOSPROYECTO_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFTIPOSPROYECTO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFTIPOSPROYECTO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de tipos de PROYECTOs
-- =============================================
CREATE PROCEDURE SP_FPADFTIPOSPROYECTO_GET 
	@pCOD_TIPOPROYECTO varchar(2) = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 COD_TIPOPROYECTO
        ,DSC_TIPOPROYECTO        
    FROM FPADFTIPOSPROYECTO
    WHERE @pCOD_TIPOPROYECTO IS NULL OR COD_TIPOPROYECTO = @pCOD_TIPOPROYECTO
    
    SET NOCOUNT OFF;
END
GO
