USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFCENTROSINVESTIGACION_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFCENTROSINVESTIGACION_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora Flores
-- Create date: 31/08/2013
-- Description:	Inserta o Actualiza info de estados de proyectos
-- =============================================
CREATE PROCEDURE SP_FPADFCENTROSINVESTIGACION_ADD 
(
			@pCOD_CENTRO VARCHAR(3),
			@pDSC_CENTRO VARCHAR(100)
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
            DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM FPADFCENTROSINVESTIGACION WHERE COD_CENTRO = @pCOD_CENTRO
                        
            IF @CANTIDAD = 0
			BEGIN
				INSERT INTO [FPADFCENTROSINVESTIGACION]
					   (COD_CENTRO
						,DSC_CENTRO)
				 VALUES
					   (@pCOD_CENTRO
						,@pDSC_CENTRO)
			END
			ELSE
			BEGIN
				UPDATE [FPADFCENTROSINVESTIGACION]
				SET COD_CENTRO = @pCOD_CENTRO
					,DSC_CENTRO = @pDSC_CENTRO
				WHERE COD_CENTRO = @pCOD_CENTRO
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











