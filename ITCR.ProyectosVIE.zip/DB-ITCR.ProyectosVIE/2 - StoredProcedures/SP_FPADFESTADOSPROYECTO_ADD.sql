USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFESTADOSPROYECTO_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFESTADOSPROYECTO_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora Flores
-- Create date: 31/08/2013
-- Description:	Inserta o Actualiza info de estados de proyectos
-- =============================================
CREATE PROCEDURE SP_FPADFESTADOSPROYECTO_ADD 
(
			@pCOD_ESTADOPROYECTO VARCHAR(2),
			@pDSC_ESTADOPROYECTO VARCHAR(40)
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
            DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM FPADFESTADOSPROYECTO WHERE COD_ESTADOPROYECTO = @pCOD_ESTADOPROYECTO
                        
            IF @CANTIDAD = 0
			BEGIN
				INSERT INTO [FPADFESTADOSPROYECTO]
					   (COD_ESTADOPROYECTO
						,DSC_ESTADOPROYECTO)
				 VALUES
					   (@pCOD_ESTADOPROYECTO
						,@pDSC_ESTADOPROYECTO)
			END
			ELSE
			BEGIN
				UPDATE [FPADFESTADOSPROYECTO]
				SET COD_ESTADOPROYECTO = @pCOD_ESTADOPROYECTO
					,DSC_ESTADOPROYECTO = @pDSC_ESTADOPROYECTO
				WHERE COD_ESTADOPROYECTO = @pCOD_ESTADOPROYECTO
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











