USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FPADFPROVINCIAS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFPROVINCIAS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFPROVINCIAS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de provincias
-- =============================================
CREATE PROCEDURE SP_FPADFPROVINCIAS_GET 
	@pCOD_PROVINCIA varchar(2) = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 COD_PROVINCIA
        ,DSC_PROVINCIA        
    FROM FPADFPROVINCIAS
    WHERE @pCOD_PROVINCIA IS NULL OR COD_PROVINCIA = @pCOD_PROVINCIA
    
    SET NOCOUNT OFF;
END
GO
