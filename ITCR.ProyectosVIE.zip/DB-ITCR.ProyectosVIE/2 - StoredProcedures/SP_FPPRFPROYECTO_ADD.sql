USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPPRFPROYECTO_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPPRFPROYECTO_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez Rojas
-- Create date: 18/08/2013
-- Description:	Inserta o Actualiza info de proyectos
-- =============================================
CREATE PROCEDURE SP_FPPRFPROYECTO_ADD 
(
			@pID_PROYECTO int = null,
			@pNOM_PROYECTO VARCHAR(100),
			@pCOD_PROYECTO VARCHAR(50),       
			@pNOM_COORDINADOR VARCHAR(60),
			@pCOD_TIPOPROYECTO VARCHAR(2),
			@pCOD_ESTADO_PROYECTO VARCHAR(2),
			@pFEC_INICIO DATETIME
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
                        
            IF @pID_PROYECTO is null
			BEGIN
				INSERT INTO [FPPRFPROYECTO]
					   (NOM_PROYECTO
						,COD_PROYECTO
						,NOM_COORDINADOR
						,COD_TIPOPROYECTO
						,COD_ESTADO_PROYECTO
						,FEC_INICIO
						,TXT_OBJETIVO
						,TXT_OBJETIVO_INGLES
						,COD_ESCUELA_RESP
						,COD_CENTRO_RESP
						,COD_PROGRAMA_DEST
						,COD_DISCIPLINA
						,COD_OBJETIVO
						,COD_POBLACION)
				 VALUES
					   (@pNOM_PROYECTO,
						@pCOD_PROYECTO,       
						@pNOM_COORDINADOR,
						@pCOD_TIPOPROYECTO,
						@pCOD_ESTADO_PROYECTO,
						@pFEC_INICIO
						,''
						,''
						,''
						,''
						,''
						,''
						,''
						,'')
			END
			ELSE
			BEGIN
				UPDATE [FPPRFPROYECTO]
				SET NOM_PROYECTO = @pNOM_PROYECTO
					,COD_PROYECTO = @pCOD_PROYECTO
					,NOM_COORDINADOR = @pNOM_COORDINADOR
					,COD_TIPOPROYECTO = @pCOD_TIPOPROYECTO
					,COD_ESTADO_PROYECTO = @pCOD_ESTADO_PROYECTO
					,FEC_INICIO = @pFEC_INICIO
				WHERE ID_PROYECTO = @pID_PROYECTO
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











