USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FPADFDISTRITOS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFDISTRITOS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFDISTRITOS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de cantones
-- =============================================
CREATE PROCEDURE SP_FPADFDISTRITOS_GET 
	@pCOD_DISTRITO VARCHAR(2),
	@pCOD_CANTON varchar(2) = null,
	@pCOD_PROVINCIA varchar(1) = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		COD_CANTON
		,COD_PROVINCIA
        ,DSC_DISTRITO        
    FROM FPADFDISTRITOS
    WHERE (@pCOD_CANTON IS NULL OR COD_CANTON = @pCOD_CANTON)
			AND (@pCOD_PROVINCIA IS NULL OR COD_PROVINCIA = @pCOD_PROVINCIA)
			AND (@pCOD_DISTRITO IS NULL OR COD_DISTRITO = @pCOD_DISTRITO)
    
    SET NOCOUNT OFF;
END
GO
