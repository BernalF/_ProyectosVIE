USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FPADFESTADOSPROYECTO_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFESTADOSPROYECTO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFESTADOSPROYECTO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de tipos de PROYECTOs
-- =============================================
CREATE PROCEDURE SP_FPADFESTADOSPROYECTO_GET 
	@pCOD_ESTADOPROYECTO varchar(2) = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 COD_ESTADOPROYECTO
        ,DSC_ESTADOPROYECTO        
    FROM FPADFESTADOSPROYECTO
    WHERE @pCOD_ESTADOPROYECTO IS NULL OR COD_ESTADOPROYECTO = @pCOD_ESTADOPROYECTO
    
    SET NOCOUNT OFF;
END
GO
