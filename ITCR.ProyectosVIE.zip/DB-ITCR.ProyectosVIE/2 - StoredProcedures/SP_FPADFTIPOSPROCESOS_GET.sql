USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FPADFTIPOSPROCESOS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFTIPOSPROCESOS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFTIPOSPROCESOS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de tipos de PROYECTOs
-- =============================================
CREATE PROCEDURE SP_FPADFTIPOSPROCESOS_GET 
	@pCOD_TIPOPROCESO varchar(2) = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 COD_TIPOPROCESO
        ,DSC_TIPOPROCESO        
    FROM FPADFTIPOSPROCESOS
    WHERE @pCOD_TIPOPROCESO IS NULL OR COD_TIPOPROCESO = @pCOD_TIPOPROCESO
    
    SET NOCOUNT OFF;
END
GO
