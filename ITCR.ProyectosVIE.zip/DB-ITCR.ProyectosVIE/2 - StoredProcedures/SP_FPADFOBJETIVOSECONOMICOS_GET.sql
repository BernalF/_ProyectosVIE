USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FPADFOBJETIVOSECONOMICOS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFOBJETIVOSECONOMICOS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFOBJETIVOSECONOMICOS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de disciplinas
-- =============================================
CREATE PROCEDURE SP_FPADFOBJETIVOSECONOMICOS_GET 
	@pCOD_OBJETIVO varchar(3) = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 COD_OBJETIVO
        ,DSC_OBJETIVO
        ,IND_ACTIVO        
    FROM FPADFOBJETIVOSECONOMICOS
    WHERE @pCOD_OBJETIVO IS NULL OR COD_OBJETIVO = @pCOD_OBJETIVO
    
    SET NOCOUNT OFF;
END
GO
