USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FPADFDISTRITOS_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FPADFDISTRITOS_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora Flores
-- Create date: 31/08/2013
-- Description:	Inserta o Actualiza info de cantones
-- =============================================
CREATE PROCEDURE SP_FPADFDISTRITOS_ADD 
(
			@pCOD_DISTRITO VARCHAR(2),
			@pCOD_CANTON VARCHAR(2),
			@pCOD_PROVINCIA VARCHAR(1),
			@pDSC_DISTRITO VARCHAR(40)
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
                        
            DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM FPADFDISTRITOS 
            WHERE COD_PROVINCIA = @pCOD_PROVINCIA AND COD_CANTON = @pCOD_CANTON AND COD_DISTRITO = @pCOD_DISTRITO
                        
            IF @CANTIDAD = 0
			BEGIN
				INSERT INTO [FPADFDISTRITOS]
					   (COD_PROVINCIA
						,DSC_DISTRITO
						,COD_CANTON
						,COD_DISTRITO)
				 VALUES
					   (@pCOD_PROVINCIA
						,@pDSC_DISTRITO
						,@pCOD_CANTON
						,@pCOD_DISTRITO)
			END
			ELSE
			BEGIN
				UPDATE [FPADFDISTRITOS]
				SET COD_PROVINCIA = @pCOD_PROVINCIA
					,DSC_DISTRITO = @pDSC_DISTRITO
					,COD_CANTON = @pCOD_CANTON
					,COD_DISTRITO = @pCOD_DISTRITO
				WHERE COD_PROVINCIA = @pCOD_PROVINCIA AND COD_CANTON = @pCOD_CANTON AND COD_DISTRITO = @pCOD_DISTRITO
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











