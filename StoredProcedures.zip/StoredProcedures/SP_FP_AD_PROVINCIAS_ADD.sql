USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_PROVINCIAS_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_PROVINCIAS_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora Flores
-- Create date: 31/08/2013
-- Description:	Inserta o Actualiza info de provincias
-- =============================================
CREATE PROCEDURE SP_FP_AD_PROVINCIAS_ADD 
(
			@pID_PROVINCIA INT = NULL,
			@pCOD_PROVINCIA VARCHAR(2),
			@pDSC_PROVINCIA VARCHAR(40),
			@pID_PAIS INT
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
                        
            DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM FP_AD_PROVINCIAS WHERE ID_PROVINCIA = @pID_PROVINCIA
                        
            IF @CANTIDAD = 0
			BEGIN
				INSERT INTO [FP_AD_PROVINCIAS]
					   (COD_PROVINCIA
						,DSC_PROVINCIA
						,ID_PAIS)
				 VALUES
					   (@pCOD_PROVINCIA
						,@pDSC_PROVINCIA
						,@pID_PAIS)
			END
			ELSE
			BEGIN
				UPDATE [FP_AD_PROVINCIAS]
				SET COD_PROVINCIA = @pCOD_PROVINCIA,
					DSC_PROVINCIA = @pDSC_PROVINCIA,
					ID_PAIS = @pID_PAIS
				WHERE ID_PROVINCIA = @pID_PROVINCIA
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











