USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_PAIS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_PAIS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_PAIS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez
-- Create date: 16/11/2013
-- Description:	Retorna una lista de PAIS
-- =============================================
CREATE PROCEDURE SP_FP_AD_PAIS_GET 
	@pID_PAIS INT = NULL
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 ID_PAIS
		 ,COD_PAIS
        ,DSC_PAIS        
    FROM FP_AD_PAIS
    WHERE @pID_PAIS IS NULL OR ID_PAIS = @pID_PAIS
    
    SET NOCOUNT OFF;
END
GO
