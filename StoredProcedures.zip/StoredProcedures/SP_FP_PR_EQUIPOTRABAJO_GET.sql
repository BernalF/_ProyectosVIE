USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_EQUIPOTRABAJO_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_EQUIPOTRABAJO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_EQUIPOTRABAJO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 28/01/2014
-- Description:	Retorna una lista de EQUIPOTRABAJO
-- =============================================
CREATE PROCEDURE SP_FP_PR_EQUIPOTRABAJO_GET 
	@pID_PROYECTO INT 	
AS
BEGIN
	
	SET NOCOUNT ON;

	SELECT	e.ID_EQUIPOTRABAJO
		   ,e.[IDENTIFICACION]
		   ,e.[NOMBRE]
		   ,e.[APELLIDOS]
		   ,e.[ID_ESCUELA]
		   ,i.DSC_NOMBRE ESCUELA
		   ,e.[NOMBRAMIENTO]
		   ,e.[JORNADA]
		   ,e.[MESES_PROYECTO]
		   ,e.[ID_TIPOSPLAZA]
		   ,p.DSC_TIPOPLAZA TIPOS_PLAZA
		   ,e.[ID_PROYECTO]  
    FROM dbo.FP_PR_EQUIPOTRABAJO e
    INNER JOIN FP_AD_INSTITUCIONES i ON i.ID_INSTITUCION = e.ID_ESCUELA
    INNER JOIN FP_AD_TIPOSPLAZA p ON p.ID_TIPOSPLAZA = e.ID_TIPOSPLAZA
    WHERE [ID_PROYECTO] = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
