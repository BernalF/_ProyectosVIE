USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PROYECTO_GET]    Script Date: 08/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PROYECTO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PROYECTO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 18/08/2013
-- Description:	Retorna una lista de proyectos
-- =============================================
CREATE PROCEDURE SP_FP_PR_PROYECTO_GET 
	@pUserName varchar(80),
	@pID_PROYECTO int = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 ID_PROYECTO
       -- ,COD_PROYECTO
        ,NOM_PROYECTO
      --  ,NOM_COORDINADOR
     --   ,COD_TIPOPROYECTO
     --   ,COD_ESTADO_PROYECTO
     --   ,FEC_INICIO
    FROM FP_PR_PROYECTO
    WHERE @pID_PROYECTO IS NULL OR ID_PROYECTO = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
GO
