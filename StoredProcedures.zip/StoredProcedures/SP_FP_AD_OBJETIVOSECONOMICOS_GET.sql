USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_OBJETIVOSECONOMICOS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_OBJETIVOSECONOMICOS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_OBJETIVOSECONOMICOS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de disciplinas
-- =============================================
CREATE PROCEDURE SP_FP_AD_OBJETIVOSECONOMICOS_GET 
	@pID_OBJETIVOSECONOMICOS INT = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 ID_OBJETIVOSECONOMICOS
		 ,COD_OBJETIVO
        ,DSC_OBJETIVO
        ,IND_ACTIVO        
    FROM FP_AD_OBJETIVOSECONOMICOS
    WHERE @pID_OBJETIVOSECONOMICOS IS NULL OR ID_OBJETIVOSECONOMICOS = @pID_OBJETIVOSECONOMICOS
    
    SET NOCOUNT OFF;
END
GO
