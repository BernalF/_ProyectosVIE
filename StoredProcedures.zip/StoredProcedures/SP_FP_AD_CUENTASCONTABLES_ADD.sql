USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_CUENTASCONTABLES_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_CUENTASCONTABLES_ADD]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora Flores
-- Create date: 31/08/2013
-- Description:	Inserta o Actualiza info de cuenta contable
-- =============================================
CREATE PROCEDURE SP_FP_AD_CUENTASCONTABLES_ADD 
(
			@pID_CUENTA INT,
			@pCOD_TIPOCUENTA VARCHAR(1),
			@pNUM_CUENTA VARCHAR(100),
			@pDSC_CUENTA VARCHAR(150),   
			@pIND_ACTIVO VARCHAR(1),
			@pDSC_ORDEN VARCHAR(2)
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0
            
            DECLARE @ActionUserID INT		
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END 
            
            DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM FP_AD_CUENTASCONTABLES WHERE ID_CUENTA = @pID_CUENTA
                        
            IF @CANTIDAD = 0
			BEGIN
				INSERT INTO [FP_AD_CUENTASCONTABLES]
					   (ID_CUENTA
						,COD_TIPOCUENTA
						,NUM_CUENTA
						,DSC_CUENTA
						,IND_ACTIVO
						,DSC_ORDEN)
				 VALUES
					   (@pID_CUENTA
						,@pCOD_TIPOCUENTA
						,@pNUM_CUENTA
						,@pDSC_CUENTA
						,@pIND_ACTIVO
						,@pDSC_ORDEN)
			END
			ELSE
			BEGIN
				UPDATE [FP_AD_CUENTASCONTABLES]
				SET COD_TIPOCUENTA = @pCOD_TIPOCUENTA
					,NUM_CUENTA = @pNUM_CUENTA
					,DSC_CUENTA = @pDSC_CUENTA
					,IND_ACTIVO = @pIND_ACTIVO
					,DSC_ORDEN = @pDSC_ORDEN
					
				WHERE ID_CUENTA = @pID_CUENTA
			END
            
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
            
            
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO











