USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_ACUERDOCONSEJO_GET]    Script Date: 01/02/2014 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_ACUERDOCONSEJO_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_ACUERDOCONSEJO_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Berman Romero
-- Create date: 02/01/2014
-- Description:	Retorna una lista de ACUERDOCONSEJO
-- =============================================
CREATE PROCEDURE SP_FP_PR_ACUERDOCONSEJO_GET 
	@pID_PROYECTO INT 	
AS
BEGIN
	
	SET NOCOUNT ON;

	SELECT	 a.ID_ACUERDOCONSEJO
			,a.ID_ESCUELA
			,a.OFICIO
			,a.ARTICULO
			,a.FECHA
			,a.ID_PROYECTO
			,b.DSC_NOMBRE AS NOMBRE_ESCUELA
    FROM dbo.FP_PR_ACUERDOCONSEJO a
    INNER JOIN dbo.FP_AD_INSTITUCIONES b ON a.ID_ESCUELA = b.ID_INSTITUCION    
    WHERE [ID_PROYECTO] = @pID_PROYECTO
    
    SET NOCOUNT OFF;
END
