USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_AD_ENTIDADESEXTERNAS_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_AD_ENTIDADESEXTERNAS_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_AD_ENTIDADESEXTERNAS_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kenneth Mora
-- Create date: 31/08/2013
-- Description:	Retorna una lista de tipos de PROYECTOs
-- =============================================
CREATE PROCEDURE SP_FP_AD_ENTIDADESEXTERNAS_GET 
	@pID_ENTIDADESEXTERNAS INT = null	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 ID_ENTIDADESEXTERNAS
		 ,COD_ENTIDAD
        ,DSC_ENTIDAD        
    FROM FP_AD_ENTIDADESEXTERNAS
    WHERE @pID_ENTIDADESEXTERNAS IS NULL OR ID_ENTIDADESEXTERNAS = @pID_ENTIDADESEXTERNAS
    
    SET NOCOUNT OFF;
END
GO
