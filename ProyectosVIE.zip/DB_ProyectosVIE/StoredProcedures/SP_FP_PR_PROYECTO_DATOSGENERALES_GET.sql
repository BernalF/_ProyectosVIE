USE [Proyectos_VIE]
GO

/****** Object:  StoredProcedure [SP_FP_PR_PROYECTO_DATOSGENERALES_GET]    Script Date: 31/18/2013 15:33:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_PROYECTO_DATOSGENERALES_GET]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_PROYECTO_DATOSGENERALES_GET]
GO

USE [Proyectos_VIE]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandex
-- Create date: 31/08/2013
-- Description:	Retorna Datos Generales
-- =============================================
CREATE PROCEDURE [SP_FP_PR_PROYECTO_DATOSGENERALES_GET] 
	@pID_PROYECTO INT	
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT
		 NOM_PROYECTO
        ,OBJETIVO
        ,PALABRASCLAVE
        ,OBJETIVO_INGLES   
        ,KEYWORDS  
    FROM [FP_PR_PROYECTO]
    WHERE @pID_PROYECTO = ID_PROYECTO
    
    SET NOCOUNT OFF;
END
GO
