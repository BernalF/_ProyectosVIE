USE [Proyectos_VIE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SP_FP_PR_DERECHOSAUTOR_ADD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [SP_FP_PR_DERECHOSAUTOR_ADD]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bernal Fernandez R.
-- Create date: 29/01/2014
-- Description:	Inserta DERECHOSAUTOR
-- =============================================
CREATE PROCEDURE [SP_FP_PR_DERECHOSAUTOR_ADD] 
(		
		   @pID_DERECHOSAUTOR INT = NULL
		  ,@pCONVENIO_NACIONAL BIT = NULL
		  ,@pCONVENIO_INTERNACIONAL BIT = NULL
		  ,@pPI_ITCR BIT = NULL
		  ,@pPI_FUNDATEC BIT = NULL
		  ,@pPI_CONTRA BIT = NULL
		  ,@pPI_CONTRA_VALOR VARCHAR(100) = NULL
		  ,@pCONVENIO_MARCO VARCHAR(100) = NULL
		  ,@pP2_PR_GEN_PROTECCION VARCHAR(500) = NULL
		  ,@pP3_PR_CORR_INVESTIGACION VARCHAR(500) = NULL
		  ,@pP4_RELACION VARCHAR(max) = NULL
		  ,@pID_PROYECTO INT
)
AS
BEGIN
	
	SET NOCOUNT ON
    SET XACT_ABORT ON
    
    BEGIN TRY
			DECLARE @lErrorMessage NVARCHAR(4000)
            DECLARE @lErrorSeverity INT
            DECLARE @lErrorState INT
            DECLARE @lLocalTran BIT = 0            
            
            IF @@TRANCOUNT = 0 
                BEGIN
                    BEGIN TRANSACTION
                    SET @lLocalTran = 1
                END                         

			DECLARE @CANTIDAD INT
            
            SELECT @CANTIDAD = COUNT(*) FROM [FP_PR_DERECHOSAUTOR] WHERE ID_PROYECTO = @pID_PROYECTO
                        
            IF @CANTIDAD = 0
            BEGIN
				INSERT INTO [dbo].[FP_PR_DERECHOSAUTOR]
					   ([CONVENIO_NACIONAL]
					  ,[CONVENIO_INTERNACIONAL]
					  ,[PI_ITCR]
					  ,[PI_FUNDATEC]
					  ,[PI_CONTRA]
					  ,[PI_CONTRA_VALOR]
					  ,[CONVENIO_MARCO]
					  ,[P2_PR_GEN_PROTECCION]
					  ,[P3_PR_CORR_INVESTIGACION]
					  ,[P4_RELACION]
					  ,[ID_PROYECTO])
				 VALUES
					   (@pCONVENIO_NACIONAL
					  ,@pCONVENIO_INTERNACIONAL
					  ,@pPI_ITCR 
					  ,@pPI_FUNDATEC
					  ,@pPI_CONTRA
					  ,@pPI_CONTRA_VALOR
					  ,@pCONVENIO_MARCO 
					  ,@pP2_PR_GEN_PROTECCION
					  ,@pP3_PR_CORR_INVESTIGACION 
					  ,@pP4_RELACION 
					  ,@pID_PROYECTO)
            END
            ELSE
            BEGIN
				UPDATE [FP_PR_DERECHOSAUTOR]
				SET  [CONVENIO_NACIONAL] = COALESCE(@pCONVENIO_NACIONAL, [CONVENIO_NACIONAL]) 
					,[CONVENIO_INTERNACIONAL] = COALESCE(@pCONVENIO_INTERNACIONAL, [CONVENIO_INTERNACIONAL]) 
					,[PI_ITCR] = COALESCE(@pPI_ITCR, [PI_ITCR]) 
					,[PI_FUNDATEC] = COALESCE(@pPI_FUNDATEC, [PI_FUNDATEC]) 
					,[PI_CONTRA] = COALESCE(@pPI_CONTRA, [PI_CONTRA]) 
					,[PI_CONTRA_VALOR] = COALESCE(@pPI_CONTRA_VALOR, [PI_CONTRA_VALOR]) 
					,[CONVENIO_MARCO] = COALESCE(@pCONVENIO_MARCO, [CONVENIO_MARCO]) 
					,[P2_PR_GEN_PROTECCION] = COALESCE(@pP2_PR_GEN_PROTECCION, [P2_PR_GEN_PROTECCION]) 
					,[P3_PR_CORR_INVESTIGACION] = COALESCE(@pP3_PR_CORR_INVESTIGACION, [P3_PR_CORR_INVESTIGACION]) 
					,[P4_RELACION] = COALESCE(@pP4_RELACION, [P4_RELACION]) 
					,[ID_PROYECTO] = COALESCE(@pID_PROYECTO, [ID_PROYECTO]) 
				WHERE ID_PROYECTO = @pID_PROYECTO
            END			
			
            IF ( @@trancount > 0
                 AND @lLocalTran = 1
               ) 
                BEGIN
                    COMMIT TRANSACTION
                END
    END TRY
    BEGIN CATCH
            IF ( @@trancount > 0
                 AND XACT_STATE() <> 0
               ) 
                BEGIN
                    ROLLBACK TRANSACTION
                END
            SELECT  @lErrorMessage = ERROR_MESSAGE() ,
                    @lErrorSeverity = ERROR_SEVERITY() ,
                    @lErrorState = ERROR_STATE()      
 
            RAISERROR (@lErrorMessage, @lErrorSeverity, @lErrorState);
        END CATCH
    END
    SET NOCOUNT OFF
    SET XACT_ABORT OFF
GO