﻿
ProyectosVIE.InsParticipantes = (function () {
    var options = {};
    var ii = [];
    var ei = [];

    //initialize function
    var initialize = function (opts) {
        $.extend(options, opts);
        getEscuelasParticipantes();
        deleteHandler();
    };

    var deleteHandler = function () {
        $('#E').off('click.tEscuelas', 'button').on('click.tEscuelas', 'button', function () {
            deleteEscuelaParticipante($(this).closest('tr'), ei);
        });
        $('#I').off('click.tInstituciones', 'button').on('click.tInstituciones', 'button', function () {
            deleteEscuelaParticipante($(this).closest('tr'), ii);
        });
    };

    var deleteEscuelaParticipante = function ($tr, items) {
        items.splice(items.indexOf($tr.attr('id')), 1);
        $.ajax({
            url: options.url.del,
            type: 'POST',
            data: JSON.stringify({ id: $tr.attr('id_ep') }),
            contentType: 'application/json; charset=utf-8',
            error: function () {
                alert("error");
            }
        });
        $tr.fadeOut().remove();
    };

    var fillList = function (data) {
        var target = data.TIPOINSTITUCION;
        var id_ep = data.ID_ESCUELASPARTICIPANTE;
        var $ddl = $('#' + target + '_ddl').find('option[value=' + data.ID_INSTITUCION + ']');
        var ddlVal = $ddl.val() != undefined ? $ddl.val() : data.ID_INSTITUCION;
        var text = $ddl.text() != '' ? $ddl.text() : data.INSTITUCION;

        switch (target) {
            case 'E':
                if (ei.indexOf(ddlVal) == -1) {
                    ei.push(ddlVal);

                    var cnt = [];
                    cnt.push('<tr id="' + ddlVal + '" id_ep="' + id_ep + '"><td><button class="btn btn-danger"><i class="icon-remove"></i></button></td><td>');
                    cnt.push(text);
                    cnt.push('</td></tr>');
                    $('#' + target).append(cnt.join(''));
                }
                else {
                    alert("La escuela seleccionada ya esta agregada");
                }
                break;
            case 'I':
                if (ii.indexOf(ddlVal) == -1) {
                    ii.push(ddlVal);

                    var cnt = [];
                    cnt.push('<tr id="' + ddlVal + '" id_ep="' + id_ep + '"><td><button class="btn btn-danger"><i class="icon-remove"></i></button></td><td>');
                    cnt.push(text);
                    cnt.push('</td></tr>');
                    $('#' + target).append(cnt.join(''));
                }
                else {
                    alert("La institución seleccionada ya esta agregada");
                }
                break;
        }
    };

    var getEscuelasParticipantes = function () {
        $.ajax({
            url: options.url.get,
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            success: function (data) {
                for (i = 0; i < data.length; i++) {
                    fillList(data[i]);
                }
            },
            error: function () {
                alert("error");
            }
        });
    };

    //Public methods
    return {
        init: initialize,
        ajaxFill: fillList
    };

})();