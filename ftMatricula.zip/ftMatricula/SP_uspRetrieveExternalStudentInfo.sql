USE [matrifunDB]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspRetrieveExternalStudentInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspRetrieveExternalStudentInfo]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Berman Romero
-- Create date: 18-Febrero-2014
-- Description:	Retrieve External Student Info 
--              from TSE temporal Table
-- =============================================
CREATE PROCEDURE [dbo].[uspRetrieveExternalStudentInfo]
	@Cedula varchar(9)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT
		 cedula
		,CASE sexo 
			WHEN '1' THEN 'M'
			WHEN '2' THEN 'F'
		 ELSE 'X'
		 END AS sexo
		,RTRIM(LTRIM(nombre)) AS nombre
		,RTRIM(LTRIM(primerApellido)) AS primerApellido
		,RTRIM(LTRIM(segundoApellido)) AS segundoApellido 
	FROM dbo.RegistroCivilPadronElectoral
	WHERE cedula = @Cedula
	
	SET NOCOUNT OFF;
END

GO


